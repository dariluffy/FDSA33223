module.exports = {
  Token: '',// توكن البوت 
  Guild: '', // ايدي السيرفر
  Channel: '', // ايدي القمناة الصوتية
  selfMute: true,   // true = كتم المايك عند الدخول، false = تشغيل المايك
  selfDeaf: false   // true = تعطيل سماع الصوت، false = سماع الصوت مفعل
};
